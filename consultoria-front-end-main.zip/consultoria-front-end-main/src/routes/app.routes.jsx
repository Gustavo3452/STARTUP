import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Feather';

import { Home } from '../pages/Home';
import { NewStartup } from '../pages/NewStartup';
import { Investing } from '../pages/Investing';
import { Reports } from '../pages/Reports';
import { Startups } from '../pages/Startups';
import { InvestingButton } from '../components/InvestingButton';
import { InsideStartups } from '../pages/InsideStartups';
import { SignIn } from '../pages/SignIn';
import { SignUp } from '../pages/SignUp';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function TabScreens() {

  const navigation = useNavigation();

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#4EAC3E',
        tabBarInactiveTintColor: '#FFF',
        tabBarHideOnKeyboard: true,
        tabBarStyle:{
          height: 60,
          backgroundColor: '#000',
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10
        }
      }}
      >
      <Tab.Screen
        name={'HomeStart'}
        component={Home}
        options={{
          tabBarIcon: ({color}) => (
            <Icon
              name={'home'}
              size={22}
              color={color}
            />
          ),
          tabBarLabel: () => {
            return (
              <Text style={{ color: '#FFF', fontFamily: 'Nunito-Regular'}}>Ínicio</Text>
            )
          },
        }}
      />

      <Tab.Screen
        name={'Add'}
        component={NewStartup}
        options={{
          tabBarIcon: ({color}) => (
            <Icon
              name={'plus-square'}
              size={22}
              color={color}
            />
          ),
          tabBarLabel: () => {
            return (
              <Text style={{ color: '#FFF', fontFamily: 'Nunito-Regular'}}>Adicionar</Text>
            )
          },

        }}
      />

      <Tab.Screen
        name={'Investing'}
        component={Investing}
        options={{
          tabBarItemStyle: {
            height: 0,
          },
          tabBarLabel: () => {
            return null;
          },
          tabBarButton: () => <InvestingButton onPress={() => navigation.navigate('InvestingStack')}/>
        }}
      />

      <Tab.Screen
        name={'Reports'}
        component={Reports}
        options={{
          tabBarIcon: ({color}) => (
            <>
              <Icon
                name={'edit-3'}
                size={22}
                color={color}
              />
             {/*  <View
                style={{
                  width: 16,
                  height: 16,
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'absolute',
                  backgroundColor: '#000',
                  borderRadius: 50,
                  top: -2,
                  right: -5,
                }}>
                <Text style={{color: '#fff', fontSize: 7}}>
                  {pedido.length}
                </Text>
              </View> */}
            </>
          ),
          tabBarLabel: () => {
            return (
              <Text style={{ color: '#FFF', fontFamily: 'Nunito-Regular'}}>Relátorios</Text>
            )
          },

        }}
      />

      <Tab.Screen
        name={'Startups'}
        component={Startups}
        options={{
          tabBarIcon: ({color}) => (
            <Icon
              name={'list'}
              size={22}
              color={color}
            />
          ),
          tabBarLabel: () => {
            return (
              <Text style={{ color: '#FFF', fontFamily: 'Nunito-Regular'}}>Startups</Text>
            )
          },
        }}
      />

    </Tab.Navigator>
  );
}

function AppRoutes() {

  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animation: 'fade_from_bottom',
      }}
    >
      <Stack.Screen
        name="SignIn"
        component={SignIn}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Home"
        component={TabScreens}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="InvestingStack"
        component={Investing}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="InsideStartups"
        component={InsideStartups}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="SignUp"
        component={SignUp}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
}
export default AppRoutes;
