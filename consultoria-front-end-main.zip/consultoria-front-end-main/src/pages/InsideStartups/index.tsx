import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { StatusBar } from 'react-native';

import {
 Container,
 Img,
 ButtonBack,
 Icon,
 Content,
 Title,
 Description,
} from './styles';

export function InsideStartups({ route }){

  const navigation = useNavigation<any>();

  const { title, img, description } = route.params.data;

  return (
    <Container>
      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle="dark-content"
      />
        <Img source={{ uri: img }}/>
        <ButtonBack onPress={() => navigation.goBack()}>
          <Icon name="arrow-left"/>
        </ButtonBack>

        <Content>
          <Title>{title}</Title>
          <Description>{description}</Description>
        </Content>
    </Container>
  );
}