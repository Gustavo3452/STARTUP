import styled from 'styled-components/native';
import FeatherIcon from 'react-native-vector-icons/Feather';

export const Container = styled.View`
  flex: 1;
`;

export const Img = styled.Image`
  width: 100%;
  height: 300px;

  background-color: #000;

  border-bottom-left-radius: 30px;
  border-bottom-right-radius: 30px;
`;

export const ButtonBack = styled.TouchableOpacity`
  width: 50px;
  height: 50px;

  background-color: #FFF;

  border-radius: 50px;

  justify-content: center;
  align-items: center;

  position: absolute;

  top: 50px;
  left: 25px;
`;

export const Icon = styled(FeatherIcon)`
  color: #000;

  font-size: 28px;
`;

export const Content = styled.ScrollView`
  flex: 1;

  padding: 20px;
`;

export const Title = styled.Text`
  color: #000;
  font-size: 18px;

  font-family: 'Nunito-Bold';
`;

export const Description =  styled.Text`
  color: #000;
  font-size: 18px;

  font-family: 'Nunito-Regular';

  line-height: 40px;

  margin-top: 30px;
`;