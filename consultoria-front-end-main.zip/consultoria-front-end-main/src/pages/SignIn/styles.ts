import styled from 'styled-components/native';

export const Container = styled.View`
  flex: 1;
`;

export const Content = styled.View`
  flex: 1;

  padding: 20px;

  justify-content: center;
  align-items: center;
`;

export const Input = styled.TextInput.attrs({
  placeholderTextColor: '#131313'
})`
  width: 100%;
  height: 60px;
  color: #000;

  background-color: #D9D9D9;

  margin-top: 20px;
  
  border-radius: 10px;

  padding: 10px;

  font-family: 'Nunito-Regular';
`;

export const ButtonSignUp = styled.TouchableOpacity``;

export const Title = styled.Text`
  color: #000;
  
  font-size: 16px;
  font-family: 'Nunito-Medium';

  margin: 10px 0px;
`;

export const ButtonSignIn = styled.TouchableOpacity`
  width: 50%;

  background-color: #001424;

  justify-content: center;
  align-items: center;

  padding: 20px 0px;

  border-radius: 10px;

  margin-top: 10px;
`;

export const ButtonSignInText = styled.Text`
  color: #FFF;
  
  font-size: 16px;
  font-family: 'Nunito-Medium';
`;
