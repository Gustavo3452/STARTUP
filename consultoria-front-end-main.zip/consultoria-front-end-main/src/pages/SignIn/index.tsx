import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator } from 'react-native';
import { Header } from '../../components/Header';

import {
 Container,
 Content,
 Input,
 ButtonSignUp,
 Title,
 ButtonSignIn,
 ButtonSignInText,
} from './styles';

export function SignIn(){

  const [loading, setLoading] = useState(false);

  const navigation = useNavigation<any>();

  const handleSignIn = () => {
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      navigation.navigate('Home');
    }, 2000);
  };

  return (
    <Container>
      <Header
        activeIcon={false}
      />

      <Content>
        <Input
          placeholder="E-mail"
          style={{ elevation: 7 }}
          />

        <Input
          placeholder="Senha"
          style={{ elevation: 7 }}
          secureTextEntry
        />

        <ButtonSignUp
          onPress={() => navigation.navigate('SignUp')}
        >
          <Title>Criar uma conta</Title>
        </ButtonSignUp>

        <ButtonSignIn
          onPress={handleSignIn}
        >
          {loading == true && (
            <ActivityIndicator color="#FFf" size="small"/>
          )}
          {loading == false && (
            <ButtonSignInText>Entrar</ButtonSignInText>
          )}
        </ButtonSignIn>
      </Content>
    </Container>
  );
}