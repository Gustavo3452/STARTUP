import React from 'react';
import { Header } from '../../components/Header';
import { Partnerships } from '../../components/Partnerships';
import { ReportsHome } from '../../components/ReportsHome';
import { WelcomeCard } from '../../components/WelcomeCard';

import {
 Container,
 Content,
} from './styles';

export function Home(){
  return (
    <Container>
      <Header
        iconName="bell"
        activeIcon={true}
      />

      <Content>
        <WelcomeCard/>
        <ReportsHome/>
        <Partnerships/>
      </Content>

    </Container>
  );
}