import React from 'react';

import {
 Container
} from './styles';

export function Reports(){
  return (
    <Container>

    </Container>
  );
}