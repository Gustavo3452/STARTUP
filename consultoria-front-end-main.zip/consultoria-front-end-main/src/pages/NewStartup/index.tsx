import React from 'react';
import {Header} from '../../components/Header';

import {
  Scroll,
  Container,
  Button, 
  Title,
  ContaintFlooter,
  Input
} from './styles';

export function NewStartup(){
  return (
    <>
    <Header/>
    <Scroll>
    <Container>
      <Button disabled style={{backgroundColor: "#001424", width: "50%", alignItems: "center"}}>
        <Title style={{color: "#fff", fontFamily: 'Nunito-Bold'}}>Junte-se a nós</Title>
      </Button>
      
      <Input
        placeholder="Nome"
        placeholderTextColor="#131313"  
      />

      <Input
        placeholder="Descrição"
        placeholderTextColor="#131313"
      />

      <Input
        placeholder="Ano fundado"
        placeholderTextColor="#131313"
        />

      <Input
        placeholder="Status"
        placeholderTextColor="#131313"
        />

      <Input
        placeholder="Localização"
        placeholderTextColor="#131313"
        />

      <Input
        placeholder="Url"
        placeholderTextColor="#131313"
        />
      
      <ContaintFlooter>
      <Button style={{backgroundColor: "#001424", width: '30%', alignItems: "center"}}>
        <Title style={{color: "#fff", fontFamily: 'Nunito-Bold'}}>Enviar</Title>
      </Button>
      </ContaintFlooter>

    </Container>
    </Scroll>
    </>
    );
}