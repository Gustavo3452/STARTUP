import styled from 'styled-components/native';
import { TouchableOpacity } from 'react-native';

export const Scroll = styled.ScrollView`

`;

export const Container = styled.KeyboardAvoidingView`
  padding: 20px;
  align-items: center;
`;
export const Button = styled(TouchableOpacity)`
  width: 100% ;
  height: 45px;
  background-color: #D9D9D9 ;
  justify-content: center;
  align-items: center;
  border-radius: 12px;
  margin-top: 10px;
  margin-bottom: 15px;
  elevation: 7;
  align-items: flex-start;
`;
export const Title = styled.Text`
  color: #000000 ;
  font-size: 20px;
  `;
export  const ContaintFlooter = styled.View`
  width: 100%;
  align-items: flex-end ;
`;
export const Input = styled.TextInput`
  width: 100% ;
  height: 45px;

  color: #000;

  background-color: #D9D9D9 ;
  justify-content: center;
  align-items: center;
  border-radius: 12px;
  margin-top: 10px;
  margin-bottom: 15px;
  elevation: 7;
  align-items: flex-start;

  padding: 10px;

  font-family: 'Nunito-Regular';
`;