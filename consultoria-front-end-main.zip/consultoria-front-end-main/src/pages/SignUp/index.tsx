import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { ActivityIndicator } from 'react-native';
import { Header } from '../../components/Header';

import {
 Container,
 Content,
 Input,
 ButtonSignUp,
 ButtonSignUpText,
} from './styles';

export function SignUp(){
  
  const navigation = useNavigation<any>();
  
  const [loading, setLoading] = useState(false);


  const handleSignUp = () => {
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      navigation.navigate('Home');
    }, 2000);
  };


  return (
    <Container>
      <Header
        activeIcon={false}
      />

      <Content>
        <Input
          placeholder="E-mail"
          style={{ elevation: 7 }}
          />

        <Input
          placeholder="Senha"
          style={{ elevation: 7 }}
          secureTextEntry
          />
        <Input
          placeholder="Confirme a senha"
          style={{ elevation: 7 }}
          secureTextEntry
        />
        <ButtonSignUp
          onPress={handleSignUp }
        >
          {loading == true && (
            <ActivityIndicator color="#FFf" size="small"/>
          )}
          {loading == false && (
            <ButtonSignUpText>Criar conta</ButtonSignUpText>
          )}
        </ButtonSignUp>
      </Content>
      
    </Container>
  );
}