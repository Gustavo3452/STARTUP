import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { Header } from '../../components/Header';
import { startups } from '../../utils/startups';

import {
 Container,
 List,
 Content,
 Img,
 Shadow,
 Title,
 PaddingFooter,

} from './styles';

export function Startups(){

  const navigation = useNavigation<any>();

  const renderItem = ({item}) => {
    return(
      <Content
        style={{ elevation: 10 }}
        activeOpacity={0.9}
        onPress={() => navigation.navigate('InsideStartups', { data: item })}
      >
        <Img source={{ uri: item.img }} resizeMode="contain"/>
        <Shadow/>
        <Title>{item.title}</Title>
      </Content>
    )
  };

  return (
    <>
    <Header/>
      <Container>
        <List
          data={startups}
          renderItem={renderItem}
          keyExtractor={(item) => String(item.id)}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={() => {
            return(
              <PaddingFooter/>
            )
          }}
        />
      </Container>
    </>
  );
}