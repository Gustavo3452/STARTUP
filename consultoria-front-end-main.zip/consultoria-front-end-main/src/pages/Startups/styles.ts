import { Dimensions, FlatList, TouchableOpacity } from 'react-native';
import styled from 'styled-components/native';

const WIDTH = Dimensions.get('window').width;

export const Container = styled.View`

  padding: 0px 20px 20px 20px;

`;

export const List = styled(FlatList)`

`;

export const Content = styled(TouchableOpacity)`
  width: ${WIDTH - 60}px;
  height: 200px;

  border-radius: 20px;

  margin: 10px 0px;
  margin-left: 10px;

  background-color: #fff;
`;

export const Img = styled.Image`
  width: 100%;
  height: 100%;

  position: absolute;

  border-radius: 10px;

  background-color: blue;
`;

export const Shadow = styled.View`
  width: 100%;
  height: 60px;

  position: absolute;

  background-color: #000;

  bottom: 0px;

  opacity: 0.2;

  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
`;

export const Title = styled.Text`
  width: 100%;

  position: absolute;

  bottom: 10px;
  left: 20px;

  color: #fff;
  font-size: 32px;
  font-family: 'Nunito-Bold';

`;

export const PaddingFooter = styled.View`
  height: 120px;
`;
