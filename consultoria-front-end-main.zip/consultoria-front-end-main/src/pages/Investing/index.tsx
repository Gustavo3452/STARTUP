import React from 'react';
import {Header} from '../../components/Header';

import {
 Container,
 Button,
 Title
} from './styles';

export function Investing(){
 return (
  <>
  <Header/>
  <Container>
    <Button disabled style={{backgroundColor: "#001424"}}>
      <Title style={{color:"#fff"}}>Como deseja Pagar?</Title>
    </Button>

    <Button>
      <Title>QR code/Link de pagamento</Title>
    </Button>

    <Button>
      <Title>Cartão de Crédito/Débito</Title>
    </Button>
  </Container>
  </>
  );
}