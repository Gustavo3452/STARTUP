import styled from 'styled-components/native';
import { TouchableOpacity } from 'react-native';

export const Container = styled.View`
  padding: 20px;
`;
export const Button = styled(TouchableOpacity)`
  width: 100% ;
  height: 74px;
  background-color: #D9D9D9 ;
  justify-content: center;
  align-items: center;
  border-radius: 12px;
  margin-top: 57px;
  elevation: 7;
`;
export const Title = styled.Text`
  color: #000000 ;
  font-size: 19px;
  
`;
