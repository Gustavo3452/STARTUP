import styled from 'styled-components/native';

export const Container = styled.View`
  width: 100%;

`;

export const TitleReports = styled.Text`
  font-size: 25px;
  color: #000;

  margin: 20px 0px;

  font-family: 'Nunito-Bold';
`;

export const ContentCard = styled.View`
  width: 100%;

  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

export const Card = styled.View`
  width: 47%;

  justify-content: center;
  align-items: center;

  background-color: #000;

  border-radius: 10px;
  padding: 30px 0px;
`;

export const Number = styled.Text`
  color: #fff;
  font-size: 32px;
  margin-bottom: 10px;

  font-family: 'Nunito-Bold';
`;

export const Title = styled.Text`
  color: #fff;
  font-size: 26px;

  font-family: 'Nunito-Regular';
`;
