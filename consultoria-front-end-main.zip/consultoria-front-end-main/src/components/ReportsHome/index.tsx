import React from 'react';

import {
 Container,
 TitleReports,
 ContentCard,
 Card,
 Number,
 Title,
} from './styles';

export function ReportsHome(){
  return (
    <Container>

      <TitleReports>Ja somos</TitleReports>

      <ContentCard>

        <Card>
          <Number>20</Number>
          <Title>investidores</Title>
        </Card>

        <Card>
          <Number>12</Number>
          <Title>startups</Title>
        </Card>

      </ContentCard>

    </Container>
  );
}