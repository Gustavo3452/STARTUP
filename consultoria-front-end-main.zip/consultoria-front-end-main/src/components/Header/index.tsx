import React from 'react';
import { StatusBar } from 'react-native';

import {
 Container,
 Img,
 Icon,
 ButtonIcon,
} from './styles';

interface Props {
  iconName?: string;
  activeIcon?: boolean;
}

export function Header({
  iconName,
  activeIcon
} : Props){
 return (
  <Container activeIcon={activeIcon}>
    <StatusBar
      barStyle="light-content"
      backgroundColor="#000"
    />
    <Img
      source={require('../../assets/Group_71.png')}
      resizeMode="contain"
    />
    {activeIcon == true && (
      <ButtonIcon>
        <Icon
          name={String(iconName)}
        />
      </ButtonIcon>
    )}
  </Container>
  );
}