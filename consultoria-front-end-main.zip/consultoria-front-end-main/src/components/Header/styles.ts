import styled from 'styled-components/native';
import Feather from 'react-native-vector-icons/Feather';

interface ContainerProps {
  activeIcon: boolean;
}

export const Container = styled.View<ContainerProps>`
  width: 100%;

  background-color: #000;

  flex-direction: row;
  justify-content: ${({ activeIcon }) => activeIcon ? 'space-between' : 'center'};
  align-items: center;

  padding: 30px;

  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
`;

export const Img = styled.Image`
  
`;

export const Icon = styled(Feather)`
  font-size: 22px;
  color: #fff;
`;

export const ButtonIcon = styled.TouchableOpacity`

`;