import React from 'react';

import {
 Container,
 Text,
} from './styles';

export function WelcomeCard(){
  return (
    <Container>
      <Text
        style={{ marginLeft: 10, marginVertical: 5, fontFamily: 'Nunito-Medium' }}
      >
        Seu Melhor
      </Text>
      <Text 
        style={{ marginLeft: 10, marginVertical: 5, textAlign: 'center', fontSize: 36, fontFamily: 'Nunito-Bold' }}
      >
        Investimento
      </Text>
      <Text 
        style={{ marginLeft: 10, marginVertical: 5, textAlign: 'right', fontFamily: 'Nunito-Medium'  }}
      >
        sem sair de casa
      </Text>
    </Container>
  );
}