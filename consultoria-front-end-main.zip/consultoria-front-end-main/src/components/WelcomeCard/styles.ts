import styled from 'styled-components/native';

export const Container = styled.View`
  width: 100%;

  background-color: #001424;

  border-radius: 10px;

  padding: 10px;
  margin-top: 20px;
`;

export const Text = styled.Text`
  color: #fff;
  font-weight: 400;
  font-size: 22px;
`;