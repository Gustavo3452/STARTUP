import styled from 'styled-components/native';
import Feather from 'react-native-vector-icons/Feather';

export const Container = styled.TouchableOpacity`
  width: 60px;
  height: 60px;

  justify-content: center;
  align-items: center;

  background-color: #4EAC3E;

  border-radius: 50px;
  

  top: -24px;
`;

export const Icon = styled(Feather)`
  color: #000;
  font-size: 22px;
`;