import React from 'react';

import {
 Container, Icon
} from './styles';

interface Props {
  onPress: () => void;
}

export function InvestingButton({onPress}: Props){
  return (
    <Container onPress={() => onPress()}>
      
      <Icon
        name="dollar-sign"
      />
    </Container>
  );
}