import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { startups } from '../../utils/startups';

import {
 Container,
 OwnerText,
 DescriptionText,
 List,
 Button,
 Partner,
 Separator,
} from './styles';

export function Partnerships(){

  const navigation = useNavigation<any>();

  return (
    <Container>
      <OwnerText>Novas Parcerias</OwnerText>
      <DescriptionText>Startups recém adicionadas</DescriptionText>

      <List
        data={startups}
        horizontal
        renderItem={({item}) => {
          return(
            <Button
              onPress={() => navigation.navigate('InsideStartups', { data: item})}
            >
              <Partner
                source={{ uri: item.img }}
                resizeMode="contain"
              />
            </Button>
          )
        }}
        keyExtractor={item => String(item)}
        ItemSeparatorComponent={() => {
          return(
            <Separator/>
          )
        }}
        showsHorizontalScrollIndicator={false}
      />
    </Container>
  );
}