import { FlatList } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View`
  margin-top: 30px;
`;

export const OwnerText = styled.Text`
  color: #000;
  font-size: 25px;
  font-family: 'Nunito-Bold';
`;

export const DescriptionText = styled.Text`
  color: #000;
  font-size: 18px;
  font-family: 'Nunito-Regular';

  margin-bottom: 10px;
`;

export const List = styled(FlatList)`

`;

export const Button = styled.TouchableOpacity`
  
`;

export const Partner = styled.Image`
  width: 100px;
  height: 100px;

  background-color: #000;

  border-radius: 50px;

  margin-top: 10px;
  margin-bottom: 40px;
`;

export const Separator = styled.View`
  width: 10px;
`;