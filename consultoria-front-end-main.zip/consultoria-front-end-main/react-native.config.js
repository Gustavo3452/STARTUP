module.exports = {
  dependencies: {},
  project: {
    ios: {},
    android: {},
  },
  assets: ['./src/assets/fonts/'],
};
